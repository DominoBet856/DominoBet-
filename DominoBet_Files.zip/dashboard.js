let currentUser = localStorage.getItem("currentUser");

if (!currentUser) {
    window.location.href = "index.html";
}

currentUser = JSON.parse(currentUser);

let users = JSON.parse(localStorage.getItem("users")) || [];

let found = users.find(u => u.email === currentUser.email);

document.getElementById("balance").innerText = found.balance + " جنيه";

function play() {
    alert("سيتم إضافة غرفة المراهنات في الخطوة القادمة 🔥");
}
